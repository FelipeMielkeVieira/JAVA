package br.senai.sc.livros.model.entities;

public class Editora {

    private String nome;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
