import java.util.Scanner;
import java.util.Random;

public class Main {

	static Scanner sc = new Scanner(System.in);
	static Jogo jogo = new Jogo();
	static Random gerador = new Random();

	public static void main(String[] args) {
		menuPrincipal();
	}

	public static void menuPrincipal() {
		System.out.println("1 - Iniciar Jogo \n2 - Encerrar");
		int opcao = sc.nextInt();

		switch (opcao) {
		case 1:
			jogo.setMatriz(gerarMatriz());
			jogar();
			break;
		case 2:
			System.exit(0);
		}
	}

	public static void jogar() {
		System.out.println(jogo.toString());
	}

	public static int[][] gerarMatriz() {

		int[][] matriz = new int[9][9];

		for (int i = 0; i < 70; i++) {
			int numeroLinha = gerador.nextInt(8);
			int numeroColuna = gerador.nextInt(8);
			int numeroFinal = gerador.nextInt(9);
			
//			if(i == 0) {
//				numeroLinha = 1;
//				numeroColuna = 1;
//				numeroFinal = 1;
//			} else {
//				numeroLinha = 2;
//				numeroColuna = 2;
//				numeroFinal = 1;
//			}

			matriz[numeroLinha][numeroColuna] = numeroFinal;
			if (!verificaJogo(matriz)) {
				matriz[numeroLinha][numeroColuna] = 0;
			}
		}
		return matriz;
	}

	public static boolean verificaJogo(int[][] matriz) {

		int variavela = 0, variavelb = 0;

		for (int linha = 0; linha < 9; linha++) {

			for (int z = 0; z < 9; z++) {

				for (int y = 0; y < 9; y++) {
					if (matriz[linha][z] == matriz[linha][y] && matriz[linha][y] != 0 && z != y) {
						return false;
					}
				}
			}
		}

		for (int coluna = 0; coluna < 9; coluna++) {

			for (int z = 0; z < 9; z++) {

				for (int y = 0; y < 9; y++) {
					if (matriz[z][coluna] == matriz[y][coluna] && matriz[y][coluna] != 0 && z != y) {
						return false;
					}
				}
			}
		}

		for (int d = 0; d < 9; d++) {

			if (d == 0) {
				variavela = 0;
				variavelb = 0;
			}
			if (d == 1) {
				variavela = 0;
				variavelb = 3;
			}
			if (d == 2) {
				variavela = 0;
				variavelb = 6;
			}
			if (d == 3) {
				variavela = 3;
				variavelb = 0;
			}
			if (d == 4) {
				variavela = 3;
				variavelb = 3;
			}
			if (d == 5) {
				variavela = 3;
				variavelb = 6;
			}
			if (d == 6) {
				variavela = 6;
				variavelb = 0;
			}
			if (d == 7) {
				variavela = 6;
				variavelb = 3;
			}
			if (d == 8) {
				variavela = 6;
				variavelb = 6;
			}

			int[] vetorQuadrado = new int[9];
			int i = 0;
			for (int linha = variavela; linha < 3; linha++) {
				for (int coluna = variavelb; coluna < 3; coluna++) {
					vetorQuadrado[i] = matriz[linha][coluna];
					i++;
				}
			}

			i = 0;	
			for(int e = 0; e < 9; e++) {
				for(int a = 0; a < 9; a++) {
					if(vetorQuadrado[e] == vetorQuadrado[a] && vetorQuadrado[e] != 0) {
						i++;
					}
				}
			}
			if(i > 1) {
				return false;
			}
		}
		return true;
	}
}
