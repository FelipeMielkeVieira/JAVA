public class Jogo {

	private int matriz[][] = new int[9][9];
	
	@Override
	public String toString() {
		
		String texto = "";
		for (int linha = 0; linha < 9; linha++) {
			for (int coluna = 0; coluna < 9; coluna++) {
				if (coluna == 2 || coluna == 5) {
					texto += this.getMatriz()[linha][coluna] + " | ";
				} else {
					texto += this.getMatriz()[linha][coluna] + " ";
				}
			}

			if (linha == 2 || linha == 5) {
				texto += "\n----------------------\n";
			} else {
				texto += "\n";
			}
		}	
		return texto;
	}

	public int[][] getMatriz() {
		return matriz;
	}

	public void setMatriz(int[][] matriz) {
		this.matriz = matriz;
	}

	public Jogo(int[][] matriz) {
		super();
		this.matriz = matriz;
	}

	public Jogo() {
		super();
	}
	
}
