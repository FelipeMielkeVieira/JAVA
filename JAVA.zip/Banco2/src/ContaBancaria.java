public abstract class ContaBancaria {

	private int numero, contagemOperacoes = 0;
	private double saldo = 0;
	
	public abstract void sacar(double valor);
	public abstract void depositar(double valor);
	public abstract String mostrarDados();
	public abstract void transferir(double valor, ContaBancaria conta);
	
	
	@Override
	public String toString() {
		return "\nN�mero: " + this.getNumero() + "\nSaldo: " + this.getSaldo();
	}
	
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	public double getSaldo() {
		return saldo;
	}
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	public int getContagemOperacoes() {
		return contagemOperacoes;
	}
	public void setContagemOperacoes(int contagemOperacoes) {
		this.contagemOperacoes = contagemOperacoes;
	}
	public ContaBancaria(int numero) {
		super();
		this.numero = numero;
	}
}
