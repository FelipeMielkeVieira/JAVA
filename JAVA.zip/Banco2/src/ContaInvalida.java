
public class ContaInvalida extends RuntimeException {

	public ContaInvalida() {
		super("Conta Inv�lida!");
	}
}
