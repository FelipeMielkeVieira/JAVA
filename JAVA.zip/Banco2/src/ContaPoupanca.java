public class ContaPoupanca extends ContaBancaria {

	private double taxaDeOperacao;
	
	@Override
	public String toString() {
		return super.toString() + "\nTaxa de Opera��o: " + this.getTaxaDeOperacao();
	}

	public double getTaxaDeOperacao() {
		return taxaDeOperacao;
	}

	public void setTaxaDeOperacao(double taxaDeOperacao) {
		this.taxaDeOperacao = taxaDeOperacao;
	}

	public ContaPoupanca(int numero, double taxaDeOperacao) {
		super(numero);
		this.taxaDeOperacao = taxaDeOperacao;
	}

	public void sacar(double valor) {
		
		double valorTotal = valor;
		if (this.getContagemOperacoes() > 4) {
			valorTotal += this.getTaxaDeOperacao();
		}
		
		if (valorTotal > this.getSaldo()) {
			throw new SaldoInvalido();
		} else {
			this.setSaldo(this.getSaldo() - valorTotal);
		}
		this.setContagemOperacoes(this.getContagemOperacoes() + 1);
	}
	
	public void depositar(double valor) {
		
		double valorTotal = valor;
		if (this.getContagemOperacoes() > 3) {
			valorTotal -= this.getTaxaDeOperacao();
		}
		
		this.setSaldo(this.getSaldo() + valorTotal);
		this.setContagemOperacoes(this.getContagemOperacoes() + 1);
	}
	
	public String mostrarDados() {
		return this.toString();
	}
	
	public void transferir(double valor, ContaBancaria conta) {
		
		if(valor > this.getSaldo()) {
			throw new SaldoInvalido();
		} else {
			this.setSaldo(this.getSaldo() - valor);
			conta.setSaldo(conta.getSaldo() + valor);
		}
	}
}
