
public class ContaExistente extends RuntimeException {

	public ContaExistente() {
		super("Conta com esse n�mero j� existe!");
	}
}
