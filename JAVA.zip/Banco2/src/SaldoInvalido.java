
public class SaldoInvalido extends RuntimeException {

	public SaldoInvalido() {
		super("Saldo Indispon�vel!");
	}
}
