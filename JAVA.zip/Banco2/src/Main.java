import java.util.Scanner;

public class Main {

	static Scanner sc = new Scanner(System.in);
	static Banco banco = new Banco();

	public static void main(String[] args) {
		menuPrincipal();
	}

	public static void menuPrincipal() {

		System.out.println(
				"----- Menu -----\n1 - Criar Conta \n2 - Selecionar Conta \n3 - Remover Conta \n4 - Gerar Relat�rio \n5 - Finalizar");
		int opcao = sc.nextInt();

		try {
			switch (opcao) {
			case 1:
				cadastroConta();
				break;
			case 2:
				System.out.print("N�mero da Conta: ");
				int numero = sc.nextInt();
				if (banco.procurarConta(numero) != null) {
					opcoesConta(banco.procurarConta(numero));
				} else {
					throw new ContaInvalida();
				}
				break;
			case 3:
				removerConta();
				break;
			case 4:
				System.out.println(banco.mostrarContas());
				break;
			case 5:
				System.exit(0);
			}
		} catch (RuntimeException exception) {
			System.out.println(exception.getClass().getSimpleName() + ": " + exception.getMessage());
		}
		menuPrincipal();
	}

	public static void cadastroConta() {

		System.out.println("----- Cadastro ------\n1 - Corrente \n2 - Poupan�a");
		int opcao = sc.nextInt();

		if (opcao != 1 && opcao != 2) {
			throw new OpcaoInvalida();
		}

		System.out.print("N�mero: ");
		int numero = sc.nextInt();

		if (banco.procurarConta(numero) != null) {
			throw new ContaExistente();
		}
		
		System.out.print("Taxa de Opera��o: ");
		double taxaDeOperacao = sc.nextDouble();

		switch (opcao) {
		case 1:
			System.out.print("Limite: ");
			double limite = sc.nextDouble();

			ContaCorrente contaCorrente = new ContaCorrente(numero, taxaDeOperacao, limite);
			banco.inserirConta(contaCorrente);
			break;
		case 2:
			ContaPoupanca contaPoupanca = new ContaPoupanca(numero, taxaDeOperacao);
			banco.inserirConta(contaPoupanca);
			break;
		}
		System.out.println("Conta Cadastrada!");
		menuPrincipal();
	}

	public static void opcoesConta(ContaBancaria conta) {

		System.out.println(
				"----- Conta -----\n1 - Depositar \n2 - Sacar \n3 - Transferir \n4 - Gerar Relat�rio \n5 - Voltar");
		int opcao = sc.nextInt();

		try {
			switch (opcao) {
			case 1:
				double valorDeposito = receberValor();
				conta.depositar(valorDeposito);
				System.out.println("Opera��o Efetuada! \nSeu saldo atual � de R$ " + conta.getSaldo());
				break;
			case 2:
				double valorSaque = receberValor();
				conta.sacar(valorSaque);
				System.out.println("Opera��o Efetuada! \nSeu saldo atual � de R$ " + conta.getSaldo());
				break;
			case 3:
				double valorTransferir = receberValor();
				System.out.print("N�mero da outra conta: ");
				int numero = sc.nextInt();

				if (banco.procurarConta(numero) != null) {
					conta.transferir(valorTransferir, banco.procurarConta(numero));
				} else {
					throw new ContaInvalida();
				}
				System.out.println("Opera��o Efetuada! \nSeu saldo atual � de R$ " + conta.getSaldo());
				break;
			case 4:
				System.out.println(conta.mostrarDados());
				break;
			case 5:
				menuPrincipal();
				break;
			}
		} catch (RuntimeException exception) {
			System.out.println(exception.getClass().getSimpleName() + ": " + exception.getMessage());
		}
		opcoesConta(conta);
	}

	public static double receberValor() {
		System.out.print("Valor: ");
		double valor = sc.nextDouble();
		if (valor > 0) {
			return valor;
		} else {
			throw new ValorInvalido();
		}
	}

	public static void removerConta() {

		System.out.print("N�mero da Conta: ");
		int numero = sc.nextInt();

		if (banco.procurarConta(numero) != null) {
			banco.removerConta(banco.procurarConta(numero));
			System.out.println("Conta Removida!");
		} else {
			throw new ContaInvalida();
		}
		menuPrincipal();
	}

}