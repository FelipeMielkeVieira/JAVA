import java.util.ArrayList;

public class Banco {

	private ArrayList<ContaBancaria> contasBancarias = new ArrayList<>();
	
	public void inserirConta(ContaBancaria conta) {
		this.contasBancarias.add(conta);
	}
	
	public void removerConta(ContaBancaria conta) {
		for(int i = 0; i < this.contasBancarias.size(); i++) {
			if(this.contasBancarias.get(i) == conta) {
				this.contasBancarias.remove(i);
			}
		}
	}
	
	public ContaBancaria procurarConta(int numero) {
		for(int i = 0; i < this.contasBancarias.size(); i++) {
			if(this.contasBancarias.get(i).getNumero() == numero) {
				return this.contasBancarias.get(i);
			}
		}
		return null;
	}
	
	public String mostrarContas() {
		String textos = "";
		for(int i = 0; i < this.contasBancarias.size(); i++) {
			textos += this.contasBancarias.get(i).toString();
		}
		return textos;
	}
}
