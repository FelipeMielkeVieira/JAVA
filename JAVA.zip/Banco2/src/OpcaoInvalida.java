
public class OpcaoInvalida extends RuntimeException {

	public OpcaoInvalida() {
		super("Opc�o Inv�lida!");
	}
}
