
public class ValorInvalido extends RuntimeException {

	public ValorInvalido() {
		super("Valor Inv�lido!");
	}
}
