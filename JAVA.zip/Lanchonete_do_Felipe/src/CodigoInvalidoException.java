
public class CodigoInvalidoException extends RuntimeException {

	public CodigoInvalidoException() {
		super("C�digo Inv�lido!");
	}
}
