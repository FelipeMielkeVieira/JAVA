
public class Outro extends Pedido {

	private String tamanho;

	@Override
	public String toString() {
		return super.toString() + "\nTamanho: " + this.getTamanho() + "\n";
	}

	public String getTamanho() {
		return tamanho;
	}

	public void setTamanho(String tamanho) {
		this.tamanho = tamanho;
	}

	public Outro() {
		super();
	}
	
	public void cadastrar() {
		Main.listaOutro.add(this);
	}
	
	public void remover(int index) {
		Main.listaOutro.remove(index);
	}
	
	public void cadastroAutomatico() {
		
		switch(this.getCodigo()) {
		case 1:
			this.setDescricao("Batata Frita");
			this.setPreco(5.00);
			this.setTamanho("Pequena");
			break;
		case 2:
			this.setDescricao("Batata Frita");
			this.setPreco(12.50);
			this.setTamanho("M�dia");
			break;
		case 3:
			this.setDescricao("Batata Frita");
			this.setPreco(20.00);
			this.setTamanho("Grande");
			break;
		case 4:
			this.setDescricao("Salada");
			this.setPreco(8.00);
			this.setTamanho("M�dia");
			break;
		}
		Main.listaOutro.add(this);
	}
	
}
