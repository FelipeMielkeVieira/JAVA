
public abstract class Pedido {

	private int codigo;
	private String descricao;
	private double preco;
	
	@Override
	public String toString() {
		return "C�digo: " + this.getCodigo() + "\nDescri��o: " + this.getDescricao() + "\nPre�o: R$" + this.getPreco();
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public double getPreco() {
		return preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}

	public Pedido(int codigo, String descricao, double preco) {
		super();
		this.codigo = codigo;
		this.descricao = descricao;
		this.preco = preco;
	}
	
	public Pedido() {
		super();
	}
	
	public abstract void cadastrar();
	public abstract void remover(int index);

	
}
