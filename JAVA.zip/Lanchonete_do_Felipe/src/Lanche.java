
public class Lanche extends Pedido {

	private double peso;

	@Override
	public String toString() {
		return super.toString() + "\nPeso: " + this.getPeso() + " kg\n";
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}

	public Lanche(int codigo, String descricao, double preco, double peso) {
		super(codigo, descricao, preco);
		this.peso = peso;
	}
	
	public void cadastrar() {
		Main.listaLanche.add(this);
	}
	
	public void remover(int index) {
		Main.listaLanche.remove(index);
	}
	
}
