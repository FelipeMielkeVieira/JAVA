
public class PesoInvalidoException extends RuntimeException {

	public PesoInvalidoException() {
		super("Peso Inv�lido!");
	}
}
