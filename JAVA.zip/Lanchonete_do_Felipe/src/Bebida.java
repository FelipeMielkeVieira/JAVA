
public class Bebida extends Pedido {

	private double volume;

	@Override
	public String toString() {
		return super.toString() + "\nVolume: " + this.getVolume() + " L\n";
	}

	public double getVolume() {
		return volume;
	}

	public void setVolume(double volume) {
		this.volume = volume;
	}

	public Bebida() {
		super();
	}

	public void cadastrar() {
		Main.listaBebida.add(this);
	}

	public void remover(int index) {
		Main.listaBebida.remove(index);
	}
	
	public void cadastroAutomatico() {
		
		switch(this.getCodigo()) {
		case 1:
			this.setDescricao("Refrigerante");
			this.setPreco(5.00);
			this.setVolume(0.35);
			break;
		case 2:
			this.setDescricao("Refrigerante");
			this.setPreco(10.00);
			this.setVolume(0.6);
			break;
		case 3:
			this.setDescricao("Suco");
			this.setPreco(6.00);
			this.setVolume(0.35);
			break;
		case 4:
			this.setDescricao("Suco");
			this.setPreco(12.00);
			this.setVolume(0.6);
			break;
		}
		Main.listaBebida.add(this);
	}
}
