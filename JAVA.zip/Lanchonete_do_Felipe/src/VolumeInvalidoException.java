
public class VolumeInvalidoException extends RuntimeException {

	public VolumeInvalidoException() {
		super("Volume Inv�lido!");
	}
}
