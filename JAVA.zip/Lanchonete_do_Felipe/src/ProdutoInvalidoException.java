
public class ProdutoInvalidoException extends RuntimeException {

	public ProdutoInvalidoException() {
		super("Produto Inv�lido!");
	}
}
