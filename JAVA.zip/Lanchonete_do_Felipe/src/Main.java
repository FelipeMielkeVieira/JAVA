import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	private static Scanner sc = new Scanner(System.in);
	public static ArrayList<Pedido> listaLanche = new ArrayList<>();
	public static ArrayList<Pedido> listaBebida = new ArrayList<>();
	public static ArrayList<Pedido> listaOutro = new ArrayList<>();

	public static void main(String[] args) {

		Lanche lanche = new Lanche(1, "X-Salada", 12.00, 0.8);
		listaLanche.add(lanche);
		Lanche lanche2 = new Lanche(2, "X-Tudo", 18.00, 1.2);
		listaLanche.add(lanche2);
		Lanche lanche3 = new Lanche(3, "X-Burguer", 10.00, 0.6);
		listaLanche.add(lanche3);
		Lanche lanche4 = new Lanche(4, "X-Bacon", 15.00, 1.0);
		listaLanche.add(lanche4);

		for(int i = 1; i <= 4; i++) {
			Bebida bebida = new Bebida();
			bebida.setCodigo(i);
			bebida.cadastroAutomatico();
		}
		
		for(int i = 1; i <= 4; i++) {
			Outro outro = new Outro();
			outro.setCodigo(i);
			outro.cadastroAutomatico();
		}
		menu();
	}

	private static void menu() {

		System.out.println("----- Menu -----" + "\n1 - Cadastrar" + "\n2 - Editar Pre�o" + "\n3 - Remover"
				+ "\n4 - Listar" + "\n5 - Encerrar");
		int opcao = sc.nextInt();
		try {
			if(opcao < 1 || opcao > 5) {
				throw new OpcaoInvalidaException();
			}
		} catch (OpcaoInvalidaException exception) {
			System.out.println(exception.getClass().getSimpleName() + ": " + exception.getMessage());
		}

		switch (opcao) {
		case 1:
			try {
				cadastrar();	
			} catch (RuntimeException exception) {
				System.out.println(exception.getClass().getSimpleName() + ": " + exception.getMessage());
				cadastrar();
			}
			break;
		case 2:
			try {
				editar();	
			} catch (RuntimeException exception) {
				System.out.println(exception.getClass().getSimpleName() + ": " + exception.getMessage());
				editar();
			}
			break;
		case 3:
			try {
				remover();
			} catch (RuntimeException exception) {
				System.out.println(exception.getClass().getSimpleName() + ": " + exception.getMessage());
				remover();	
			}
			break;
		case 4:
			try {
				listar();	
			} catch (RuntimeException exception) {
				System.out.println(exception.getClass().getSimpleName() + ": " + exception.getMessage());
				listar();
			}
			break;
		case 5:
			System.exit(0);
			break;
		}
		menu();
	}

	private static void cadastrar() {

		System.out.println("----- Cadastrar -----");
		int opcao = selecionaTipo();
		Pedido pedido = coletaDados(opcao);			

		if (confirmacao(1) == 1) {
			pedido.cadastrar();
			System.out.println("Pedido Cadastrado!");
		}
		cadastrar();
	}

	private static Pedido coletaDados(int tipo) {

		System.out.print("C�digo: ");
		int codigo = sc.nextInt();

		if (valida(tipo, codigo) != -1) {
			throw new CodigoInvalidoException();
		}

		sc.nextLine();
		System.out.print("Descri��o: ");
		String descricao = sc.nextLine();
		System.out.print("Pre�o: ");
		double preco = sc.nextDouble();
		
		if(preco < 0) {
			throw new PrecoInvalidoException();
		}

		switch (tipo) {
		case 1:
			System.out.print("Peso: ");
			double peso = sc.nextDouble();
			
			if(peso < 0) {
				throw new PesoInvalidoException();
			}
			Lanche lanche = new Lanche(codigo, descricao, preco, peso);
			return lanche;
		case 2:
			Bebida bebida = new Bebida();
			bebida.setCodigo(codigo);
			bebida.setDescricao(descricao);
			bebida.setPreco(preco);

			System.out.print("Volume: ");
			bebida.setVolume(sc.nextDouble());
			
			if(bebida.getVolume() < 0) {
				throw new VolumeInvalidoException();
			}
			return bebida;
		case 3:
			Outro outro = new Outro();
			outro.setCodigo(codigo);
			outro.setDescricao(descricao);
			outro.setPreco(preco);

			System.out.print("Tamanho: ");
			outro.setTamanho(sc.next());
			return outro;
		}
		return null;
	}

	private static int selecionaTipo() {
		System.out.println("1 - Lanche" + "\n2 - Bebida" + "\n3 - Outro" + "\n4 - Voltar");
		int opcao = sc.nextInt();

		if (opcao == 4) {
			menu();
		}
		if(opcao < 1 || opcao > 4) {
			throw new OpcaoInvalidaException();
		}
		return opcao;
	}

	private static void editar() {

		System.out.println("----- Editar Pre�o -----");
		int opcao = selecionaTipo();

		System.out.print("C�digo: ");
		int codigo = sc.nextInt();

		if (valida(opcao, codigo) == -1) {
			throw new ProdutoInvalidoException();
		}
		System.out.print("Novo Pre�o: ");
		double preco = sc.nextDouble();
		
		if(preco < 0) {
			throw new PrecoInvalidoException();
		}

		Pedido pedido = receberObjeto(opcao, codigo);
		pedido.setPreco(preco);

		editar();
	}

	private static void remover() {

		System.out.println("----- Remover -----");
		int opcao = selecionaTipo();

		System.out.print("C�digo: ");
		int codigo = sc.nextInt();

		if (valida(opcao, codigo) == -1) {
			throw new ProdutoInvalidoException();
		}

		int index = valida(opcao, codigo);
		Pedido pedidoTemp = receberObjeto(opcao, codigo);
		
		if(confirmacao(2) == 1) {
			pedidoTemp.remover(index);
			System.out.println("Pedido Exclu�do!");
		}

		remover();
	}

	private static void listar() {

		System.out.println("----- Listar -----");
		int opcao = selecionaTipo();
		switch (opcao) {
		case 1:
			for (int i = 0; i < listaLanche.size(); i++) {
				System.out.println(listaLanche.get(i).toString());
			}
			break;
		case 2:
			for (int i = 0; i < listaBebida.size(); i++) {
				System.out.println(listaBebida.get(i).toString());
			}
			break;
		case 3:
			for (int i = 0; i < listaOutro.size(); i++) {
				System.out.println(listaOutro.get(i).toString());
			}
			break;
		case 4:
			menu();
			break;
		}
		listar();
	}

	private static int valida(int opcao, int codigo) {

		switch (opcao) {
		case 1:
			for (int i = 0; i < listaLanche.size(); i++) {
				if (listaLanche.get(i).getCodigo() == codigo) {
					return i;
				}
			}
			break;
		case 2:
			for (int i = 0; i < listaBebida.size(); i++) {
				if (listaBebida.get(i).getCodigo() == codigo) {
					return i;
				}
			}
			break;
		case 3:
			for (int i = 0; i < listaOutro.size(); i++) {
				if (listaOutro.get(i).getCodigo() == codigo) {
					return i;
				}
			}
			break;
		}
		return -1;
	}

	private static Pedido receberObjeto(int opcao, int codigo) {

		switch (opcao) {
		case 1:
			for (int i = 0; i < listaLanche.size(); i++) {
				if (listaLanche.get(i).getCodigo() == codigo) {
					return listaLanche.get(i);
				}
			}
			break;
		case 2:
			for (int i = 0; i < listaBebida.size(); i++) {
				if (listaBebida.get(i).getCodigo() == codigo) {
					return listaBebida.get(i);
				}
			}
			break;
		case 3:
			for (int i = 0; i < listaOutro.size(); i++) {
				if (listaOutro.get(i).getCodigo() == codigo) {
					return listaOutro.get(i);
				}
			}
			break;
		}
		return null;
	}

	private static int confirmacao(int opcao) {
		int escolha = 0;
		switch (opcao) {
		case 1:
			System.out.println("Tem certeza que deseja cadastrar esse item? \n1 - Sim \n2 - N�o");
			escolha = sc.nextInt();
			break;
		case 2:
			System.out.println("Tem certeza que deseja remover esse item? \n1 - Sim \n2 - N�o");
			escolha = sc.nextInt();
		}
		return escolha;
	}
}