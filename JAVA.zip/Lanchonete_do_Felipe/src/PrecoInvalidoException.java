
public class PrecoInvalidoException extends RuntimeException {

	public PrecoInvalidoException() {
		super("Pre�o Inv�lido!");
	}
}
