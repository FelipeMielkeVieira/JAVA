
public class Livro {

	private Autor autor;
	private Editora editora;
	private String titulo;
	private int status, isbn, totalPaginas, paginasAtuais;

	@Override
	public String toString() {
		String statusFinal;
		String resposta;

		if (this.getStatus() == 1) {
			statusFinal = "Aguardando Revis�o";
		} else if (this.getStatus() == 2) {
			statusFinal = "Em Revis�o";
		} else if (this.getStatus() == 3) {
			statusFinal = "Reprovado";
		} else if (this.getStatus() == 4) {
			statusFinal = "Aprovado";
		} else if (this.getStatus() == 5) {
			statusFinal = "Aguardando Edi��o";
		} else {
			statusFinal = "Publicado";
		}
		if (this.getEditora() != null) {
			resposta = "Autor: " + this.getAutor().getNome() + " " + this.getAutor().getSobrenome() + "\nEditora: "
					+ this.getEditora().getNome() + "\nT�tulo: " + this.getTitulo() + "\nISBN: " + this.getIsbn()
					+ "\nTotal de P�ginas: " + this.getTotalPaginas() + "\nStatus: " + statusFinal + "\n";
		} else {
			resposta = "Autor: " + this.getAutor().getNome() + " " + this.getAutor().getSobrenome() + "\nT�tulo: "
					+ this.getTitulo() + "\nISBN: " + this.getIsbn() + "\nTotal de P�ginas: " + this.getTotalPaginas()
					+ "\nStatus: " + statusFinal + "\n\n";
		}
		return resposta;
	}

	public Autor getAutor() {
		return autor;
	}

	public void setAutor(Autor autor) {
		this.autor = autor;
	}

	public Editora getEditora() {
		return editora;
	}

	public void setEditora(Editora editora) {
		this.editora = editora;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public int getIsbn() {
		return isbn;
	}

	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}

	public int getTotalPaginas() {
		return totalPaginas;
	}

	public void setTotalPaginas(int totalPaginas) {
		this.totalPaginas = totalPaginas;
	}

	public int getPaginasAtuais() {
		return paginasAtuais;
	}

	public void setPaginasAtuais(int paginasAtuais) {
		this.paginasAtuais = paginasAtuais;
	}

	public Livro(Autor autor, String titulo, int status, int isbn, int totalPaginas, int paginasAtuais) {
		super();
		this.autor = autor;
		this.titulo = titulo;
		this.status = status;
		this.isbn = isbn;
		this.totalPaginas = totalPaginas;
		this.paginasAtuais = paginasAtuais;
	}

	// 1 - Aguardando Revis�o
	// 2 - Em Revis�o
	// 3 - Reprovado
	// 4 - Aprovado
	// 5 - Aguardando Edi��o
	// 6 - Publicado
}
