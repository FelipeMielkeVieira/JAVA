import java.util.ArrayList;

public class Revisor extends Pessoa {

	private ArrayList<Livro> listaLivrosRevisor;

	public Revisor() {
		super();
	}

	public ArrayList<Livro> getListaLivrosRevisor() {
		return listaLivrosRevisor;
	}

	public void setListaLivrosRevisor(ArrayList<Livro> listaLivrosRevisor) {
		this.listaLivrosRevisor = listaLivrosRevisor;
	}

	public Revisor(int matricula, String senha, String nome, String cpf, String sobrenome, String email,
			String genero) {
		super(matricula, senha, nome, cpf, sobrenome, email, genero);
	}

	@Override
	public String listarLivros() {
		String livros = "";
		for (int i = 0; i < Main.listaLivros.size(); i++) {
			if (Main.listaLivros.get(i).getStatus() == 1) {
				livros += Main.listaLivros.get(i).toString();
			}
		}
		return livros;
	}

	@Override
	public void editarLivro() {
		int indiceLivro = Main.indexLivro();
		if (indiceLivro != -1) {
			if (Main.listaLivros.get(indiceLivro).getStatus() == 1) {
				Main.listaLivros.get(indiceLivro).setStatus(2);
				this.listaLivrosRevisor.add(Main.listaLivros.get(indiceLivro));
			} else if (Main.listaLivros.get(indiceLivro).getStatus() == 2) {
				int status = Main.selecionaEdicao(indiceLivro);
				switch (status) {
				case 1:
					if (Main.listaLivros.get(indiceLivro).getPaginasAtuais() == Main.listaLivros.get(indiceLivro)
							.getTotalPaginas()) {
						Main.listaLivros.get(indiceLivro).setStatus(4);
						this.getListaLivrosRevisor().remove(indiceLivro);
					}
					break;
				case 2:
					Main.listaLivros.get(indiceLivro).setStatus(3);
					this.getListaLivrosRevisor().remove(indiceLivro);
					break;
				case 3:
					Main.listaLivros.get(indiceLivro).setStatus(5);
					this.getListaLivrosRevisor().remove(indiceLivro);
					break;
				default:
					throw new OpcaoInvalidaException();
				}
			}
		} else {
			throw new LivroInvalidoException();
		}
	}

	public String[] opcoes() {
		return new String[] { "1 - Atividades", "2 - Livros", "3 - Logout" };
	}

	@Override
	public String listarAtividades() {
		String livros = "";
		for (int i = 0; i < this.listaLivrosRevisor.size(); i++) {
			livros += this.listaLivrosRevisor.get(i).toString();
		}
		return livros;
	}

	// listar suas atividades (em revis�o)
	// listar livros (aguardando revis�o)
	// editar livros (reprovado, aprovado, em revis�o, aguardando edi��o)
}
