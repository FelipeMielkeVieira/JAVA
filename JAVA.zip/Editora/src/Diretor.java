
public class Diretor extends Pessoa {

	public Diretor() {
		super();
	}

	public Diretor(int matricula, String senha, String nome, String cpf, String sobrenome, String email,
			String genero) {
		super(matricula, senha, nome, cpf, sobrenome, email, genero);
	}

	@Override
	public String listarLivros() {
		String livros = "";
		for (int i = 0; i < Main.listaLivros.size(); i++) {
			livros += Main.listaLivros.get(i).toString();
		}
		return livros;
	}

	@Override
	public void editarLivro() {
		int indiceLivro = Main.indexLivro();
		if (indiceLivro != -1) {
			int status = Main.selecionaEdicao();
			switch (status) {
			case 1:
				Main.listaLivros.get(indiceLivro).setStatus(6);
				break;
			case 2:
				Main.listaLivros.get(indiceLivro).setStatus(3);
				break;
			case 3:
				Main.listaLivros.get(indiceLivro).setStatus(1);
				break;
			default:
				throw new OpcaoInvalidaException();
			}
		} else {
			throw new LivroInvalidoException();
		}
	}

	public String[] opcoes() {
		return new String[] { "1 - Atividades", "2 - Livros", "3 - Cadastrar Revisor", "4 - Logout" };
	}

	@Override
	public String listarAtividades() {
		String livros = "";
		for (int i = 0; i < Main.listaLivros.size(); i++) {
			if (Main.listaLivros.get(i).getStatus() == 4) {
				livros += Main.listaLivros.get(i).toString();
			}
		}
		return livros;
	}

	// editar livro (publicar, reprovar, aguardando revis�o)
	// listar atividades (aprovados)
	// cadastrar revisor
	// listar livros (todos)
}
