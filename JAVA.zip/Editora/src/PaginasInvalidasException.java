
public class PaginasInvalidasException extends RuntimeException {

	public PaginasInvalidasException() {
		super("Quantidade de p�ginas inv�lidas!");
	}
}
