
public class UsuarioInvalidoException extends RuntimeException {

	public UsuarioInvalidoException() {
		super("Usu�rio Inv�lido!");
	}
}
