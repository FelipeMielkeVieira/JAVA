
public abstract class Pessoa {

	private int matricula;
	private String senha, nome, cpf, sobrenome, email, genero;

	public abstract String listarLivros();

	public abstract void editarLivro();

	public abstract String[] opcoes();

	public abstract String listarAtividades();

	@Override
	public String toString() {
		return "Pessoa [matricula=" + matricula + ", senha=" + senha + ", nome=" + nome + ", cpf=" + cpf
				+ ", sobrenome=" + sobrenome + ", email=" + email + ", genero=" + genero + "]";
	}

	public int getMatricula() {
		return matricula;
	}

	public void setMatricula(int matricula) {
		this.matricula = matricula;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getSobrenome() {
		return sobrenome;
	}

	public void setSobrenome(String sobrenome) {
		this.sobrenome = sobrenome;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(String genero) {
		this.genero = genero;
	}

	public Pessoa() {
		super();
	}

	public Pessoa(int matricula, String senha, String nome, String cpf, String sobrenome, String email, String genero) {
		super();
		this.matricula = matricula;
		this.senha = senha;
		this.nome = nome;
		this.cpf = cpf;
		this.sobrenome = sobrenome;
		this.email = email;
		this.genero = genero;
	}

}
