
public class MatriculaInvalidaException extends RuntimeException {

	public MatriculaInvalidaException() {
		super("Matr�cula Inv�lida!");
	}
}
