
public class OpcaoInvalidaException extends RuntimeException {

	public OpcaoInvalidaException() {
		super("Op��o Inv�lida!");
	}
}
