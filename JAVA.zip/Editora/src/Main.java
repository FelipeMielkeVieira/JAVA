import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	private static Scanner sc = new Scanner(System.in);
	public static ArrayList<Livro> listaLivros = new ArrayList<>();
	public static ArrayList<Pessoa> listaPessoas = new ArrayList<>();
	private static ArrayList<Editora> listaEditoras = new ArrayList<>();
	public static Pessoa usuario;

	public static void main(String[] args) {
		Diretor diretor = new Diretor(1, "123", "Felipe", "123456789", "Vieira", "felipe@gmail.com", "M");
		listaPessoas.add(diretor);
		cadastrarEditoras();
		menuPrincipal();
	}

	private static void menuPrincipal() {
		System.out.println("----- Menu -----\n1 - Login \n2 - Cadastrar Autor \n3 - Encerrar");
		int opcao = sc.nextInt();
		
		try {
			if(opcao < 1 || opcao > 3) {
				throw new OpcaoInvalidaException();
			}
		} catch (OpcaoInvalidaException exception) {
			System.out.println(exception.getClass().getSimpleName() + ": " + exception.getMessage());
		}
		
		switch (opcao) {
		case 1:
			try {
				login();	
			} catch (OpcaoInvalidaException exception) {
				System.out.println(exception.getClass().getSimpleName() + ": " + exception.getMessage());
				login();
			}
			break;
		case 2:
			cadastro();
			break;
		case 3:
			System.exit(0);
		}
		menuPrincipal();
	}

	private static void login() {
		System.out.println("----- Login -----\n1 - Autor \n2 - Revisor \n3 - Diretor \n4 - Voltar");
		int opcao = sc.nextInt();
		System.out.print("Matr�cula: ");
		int matricula = sc.nextInt();
		System.out.print("Senha: ");
		String senha = sc.next();
		
		try {
			switch (opcao) {
			case 1:
				if (validarPessoa(indexPessoa(1, matricula), senha)) {
					menu();
				}
				break;
			case 2:
				if (validarPessoa(indexPessoa(2, matricula), senha)) {
					menu();
				}
				break;
			case 3:
				if (validarPessoa(indexPessoa(3, matricula), senha)) {
					menu();
				}
				break;
			case 4:
				menuPrincipal();
				break;
			}	
		} catch (UsuarioInvalidoException exception) {
			System.out.println(exception.getClass().getSimpleName() + ": " + exception.getMessage());
		}
		login();
	}

	private static void cadastro() {
		Pessoa pessoa = null;
		try {
			pessoa = cadastroPessoa(1);	
		} catch (RuntimeException exception) {
			System.out.println(exception.getClass().getSimpleName() + ": " + exception.getMessage());
			cadastro();
		}
		usuario = pessoa;
		listaPessoas.add(pessoa);
		menu();
	}

	public static void menu() {
		System.out.println("----- Menu -----");
		String[] opcoes = usuario.opcoes();
		for (String opcao : opcoes) {
			System.out.println(opcao);
		}
		int escolha = sc.nextInt();
		
		try {
			if (escolha == opcoes.length) {
				menuPrincipal();
			} else if (escolha < 1 || escolha > opcoes.length) {
				throw new OpcaoInvalidaException();
			} else {
				switch (escolha) {
				case 1:
					if (! usuario.listarAtividades().equals("")) {
						System.out.println(usuario.listarAtividades());
						int resposta;
						do {
							System.out.println("Deseja editar algum livro? \n1 - Sim \n2 - N�o");
							resposta = sc.nextInt();
							if (resposta == 1) {
								usuario.editarLivro();
							}
						} while (resposta < 1 || resposta > 2);
					} else {
						System.out.println("Sem Livros para editar!");
					}
				case 2:
					System.out.println(usuario.listarLivros());
					break;
				case 3:
					if (usuario instanceof Diretor) {
						listaPessoas.add(cadastroPessoa(2));
					} else {
						listaLivros.add(cadastroLivro());
					}
					break;
				}
			}	
		} catch (RuntimeException exception) {
			System.out.println(exception.getClass().getSimpleName() + ": " + exception.getMessage());
		}
		menu();
	}

	private static Pessoa cadastroPessoa(int opcao) {

		System.out.println("----- Cadastro -----");
		System.out.print("Matr�cula: ");
		int matricula = sc.nextInt();
		if (indexPessoa(opcao, matricula) != -1) {
			throw new MatriculaInvalidaException();
		}
		System.out.print("Senha: ");
		String senha = sc.next();
		System.out.print("Nome: ");
		String nome = sc.next();
		System.out.print("Sobrenome: ");
		String sobrenome = sc.next();
		System.out.print("CPF: ");
		String cpf = sc.next();
		System.out.print("Email: ");
		String email = sc.next();
		System.out.print("G�nero: ");
		String genero = sc.next();

		switch (opcao) {
		case 1:
			return new Autor(matricula, senha, nome, cpf, sobrenome, email, genero);
		case 2:
			return new Revisor(matricula, senha, nome, cpf, sobrenome, email, genero);
		}
		return null;
	}

	private static Livro cadastroLivro() {

		sc.nextLine();
		System.out.print("T�tulo: ");
		String titulo = sc.nextLine();
		System.out.print("ISBN: ");
		int isbn = sc.nextInt();
		
		if(returnIndexLivro(isbn) != -1) {
			throw new LivroExistenteException();
		}
		
		System.out.print("Quantidade de P�ginas: ");
		int qtdPaginas = sc.nextInt();
		return new Livro((Autor) (usuario), titulo, 1, isbn, qtdPaginas, 0);
	}

	private static int indexPessoa(int opcao, int matricula) {
		switch (opcao) {
		case 1:
			for (int i = 0; i < listaPessoas.size(); i++) {
				if (listaPessoas.get(i).getMatricula() == matricula && listaPessoas.get(i) instanceof Autor) {
					return i;
				}
			}
			break;
		case 2:
			for (int i = 0; i < listaPessoas.size(); i++) {
				if (listaPessoas.get(i).getMatricula() == matricula && listaPessoas.get(i) instanceof Revisor) {
					return i;
				}
			}
			break;
		case 3:
			for (int i = 0; i < listaPessoas.size(); i++) {
				if (listaPessoas.get(i).getMatricula() == matricula && listaPessoas.get(i) instanceof Diretor) {
					return i;
				}
			}
			break;
		}
		return -1;
	}

	public static int indexLivro() {
		System.out.println("Selecione o livro a ser editado:");
		int isbn = sc.nextInt();

		for (int i = 0; i < listaLivros.size(); i++) {
			if (listaLivros.get(i).getIsbn() == isbn) {
				return i;
			}
		}
		return -1;
	}
	
	public static int returnIndexLivro(int isbn) {
		for (int i = 0; i < listaLivros.size(); i++) {
			if (listaLivros.get(i).getIsbn() == isbn) {
				return i;
			}
		}
		return -1;
	}

	private static boolean validarPessoa(int index, String senha) {
		
		if(index == -1) {
			throw new UsuarioInvalidoException();
		}
		
		if (listaPessoas.get(index).getSenha().equals(senha)) {
			usuario = listaPessoas.get(index);
			return true;
		} else {
			return false;
		}
	}

	private static void cadastrarEditoras() {
		Editora editora = new Editora("Ferraria", "1");
		Editora editora2 = new Editora("Saraiva", "2");
		Editora editora3 = new Editora("Kalunga", "3");
		Editora editora4 = new Editora("Pachinko", "4");
		Editora editora5 = new Editora("Domin�", "5");
		listaEditoras.add(editora);
		listaEditoras.add(editora2);
		listaEditoras.add(editora3);
		listaEditoras.add(editora4);
		listaEditoras.add(editora5);
	}

	public static int selecionaEdicao(int indexLivro) {
		System.out.print("P�ginas Lidas: ");
		int paginas = sc.nextInt();
		if ((listaLivros.get(indexLivro).getPaginasAtuais() + paginas) > listaLivros.get(indexLivro)
				.getTotalPaginas()) {
			throw new PaginasInvalidasException();
		} else {
			listaLivros.get(indexLivro).setPaginasAtuais(listaLivros.get(indexLivro).getPaginasAtuais() + paginas);
		}
		if (listaLivros.get(indexLivro).getPaginasAtuais() == listaLivros.get(indexLivro).getTotalPaginas()) {
			System.out.println("1 - Aprovar \n2 - Reprovar \n3 - Mandar para Edi��o");
		} else {
			System.out.println("1 - Continuar Revisando \n2 - Reprovar \n3 - Mandar para Edi��o");
		}
		return sc.nextInt();
	}

	public static int selecionaEdicao() {
		System.out.println("1 - Publicar \n2 - Reprovar \n3 - Mandar para Revis�o");
		return sc.nextInt();
	}
}
