
public class Autor extends Pessoa {

	public Autor() {
		super();
	}

	public Autor(int matricula, String senha, String nome, String cpf, String sobrenome, String email, String genero) {
		super(matricula, senha, nome, cpf, sobrenome, email, genero);
	}

	@Override
	public String listarLivros() {
		String livros = "";
		for (int i = 0; i < Main.listaLivros.size(); i++) {
			System.out.println("---------------------------");
			if (Main.listaLivros.get(i).getAutor() == Main.usuario) {
				livros += Main.listaLivros.get(i).toString();
			}
		}
		return livros;
	}

	@Override
	public void editarLivro() {
		int indiceLivro = Main.indexLivro();
		if (indiceLivro != -1) {
			Main.listaLivros.get(indiceLivro).setStatus(1);
		} else {
			throw new LivroInvalidoException();
		}
	}

	public String[] opcoes() {
		return new String[] { "1 - Listar Atividades", "2 - Livros", "3 - Cadastrar Livro", "4 - Logout" };
	}

	@Override
	public String listarAtividades() {
		String livros = "";
		for (int i = 0; i < Main.listaLivros.size(); i++) {
			if (Main.listaLivros.get(i).getAutor() == Main.usuario && Main.listaLivros.get(i).getStatus() == 5) {
				livros += Main.listaLivros.get(i).toString();
			}
		}
		return livros;
	}

	// cadastrarLivro
	// listar os seus livros
	// editar livro
}
