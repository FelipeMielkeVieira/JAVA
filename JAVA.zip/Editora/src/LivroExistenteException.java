
public class LivroExistenteException extends RuntimeException {

	public LivroExistenteException() {
		super("Livro Existente!");
	}
}
