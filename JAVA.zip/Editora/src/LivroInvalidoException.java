
public class LivroInvalidoException extends RuntimeException {

	public LivroInvalidoException() {
		super("Livro Inv�lido!");
	}
}
