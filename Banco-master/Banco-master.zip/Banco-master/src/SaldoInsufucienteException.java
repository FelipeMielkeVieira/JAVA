public class SaldoInsufucienteException extends RuntimeException {
    public SaldoInsufucienteException() {
        super("Saldo insuficiente!");
    }
}
