public interface Interface {
    public void inserir();
    public void remover();
}
