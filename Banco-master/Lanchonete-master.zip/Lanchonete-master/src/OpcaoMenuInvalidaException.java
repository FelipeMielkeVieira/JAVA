public class OpcaoMenuInvalidaException extends RuntimeException {
    public OpcaoMenuInvalidaException(){
        super("Op��o do menu inexistente!");
    }
}
